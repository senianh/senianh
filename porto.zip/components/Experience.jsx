const experiences = [
  {
    title: "Public Relations Manager",
    organization: "IFEST",
    year: "2025",
  },
  {
    title: "Artificial Intelligence Project",
    organization: "Adaptive Scheduling for Medical Students",
    year: "2025",
  },
  {
    title: "Data Science Project",
    organization: "Food Commodity Price Forecasting",
    year: "2025",
  },
];

export default function Experience() {
  return (
    <section
      id="experience"
      style={{ background: "#0c0c0c", padding: "120px 80px", borderTop: "1px solid #111" }}
    >
      <p style={{ color: "#ff5c8d", letterSpacing: "0.2em", marginBottom: 16, fontSize: "0.8rem" }}>
        EXPERIENCE
      </p>

      <h2 style={{
        fontSize: "3rem",
        fontFamily: "'Cormorant Garamond', serif",
        color: "white",
        marginBottom: 60,
      }}>
        My Journey
      </h2>

      <div style={{ display: "flex", flexDirection: "column", gap: 40 }}>
        {experiences.map((exp, index) => (
          <div
            key={exp.title}
            style={{
              display: "grid",
              gridTemplateColumns: "80px 1fr",
              gap: 32,
              alignItems: "start",
            }}
          >
            <div style={{
              fontSize: "3rem",
              fontFamily: "'Cormorant Garamond', serif",
              color: "rgba(255,255,255,0.1)",
              lineHeight: 1,
              fontWeight: 600,
            }}>
              {String(index + 1).padStart(2, "0")}
            </div>

            <div style={{ borderLeft: "2px solid #ff5c8d", paddingLeft: 28 }}>
              <h3 style={{ fontSize: "1.2rem", fontWeight: 600, color: "white", marginBottom: 8 }}>
                {exp.title}
              </h3>
              <p style={{ color: "#888", marginBottom: 4 }}>{exp.organization}</p>
              <p style={{ color: "#555", fontSize: "0.85rem" }}>{exp.year}</p>
            </div>
          </div>
        ))}
      </div>

      <div style={{
        marginTop: 120,
        paddingTop: 40,
        borderTop: "1px solid #111",
        textAlign: "center",
        color: "#333",
        fontSize: "0.8rem",
        letterSpacing: "0.2em",
      }}>
        CREATED BY SENIA NUR HASANAH — 140810230021
      </div>
    </section>
  );
}
